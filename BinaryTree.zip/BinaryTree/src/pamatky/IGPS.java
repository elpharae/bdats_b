package pamatky;

public interface IGPS {
    
    float vzdalenostOd(GPS gps);

}
