package pamatky;

public class PamatkyException extends Exception {

    public PamatkyException(String message) {
        super(message);
    }

}
