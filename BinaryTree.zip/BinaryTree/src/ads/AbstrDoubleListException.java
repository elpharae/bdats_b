package ads;

public class AbstrDoubleListException extends Exception {

    public AbstrDoubleListException(String message) {
        super(message);
    }
    
}
