package ads;

public class AbstrTableException extends Exception {

    public AbstrTableException(String message) {
        super(message);
    }
    
}
